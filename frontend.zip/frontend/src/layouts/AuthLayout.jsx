import React from "react";

const AuthLayout = ({ element }) => {
  return <main>{element}</main>; // tanpa nav dan footer
};

export default AuthLayout;